"""Run one pilot or a five-way cold pipeline creation test in a disposable prefix."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from shaders import expected, generate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("count", type=int, choices=(1, 5))
    parser.add_argument("--build-dir", type=Path, help="TuxBox build directory containing pipeline-candidate, validation-tools and lanes-prefix")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir()
    here = Path(__file__).resolve().parent
    build = args.build_dir.resolve() if args.build_dir else here.parent
    repo = build / "pipeline-candidate"
    tools = build / "validation-tools"
    sys.path[:0] = [str(repo / "tools"), str(repo)]
    from frosty_gpu_guest import run_gpu_guest
    dxc = tools / "dxc/bin/dxc"
    os.environ.update(PATH=f"{tools}/llvm19/usr/lib/llvm-19/bin:{os.environ['PATH']}",
                      LD_LIBRARY_PATH=f"{tools}/llvm19/usr/lib/x86_64-linux-gnu:" + os.environ.get("LD_LIBRARY_PATH", ""),
                      XWIN_SDK_ROOT=str(tools / "cache/cargo-xwin/xwin"), DXC=str(dxc),
                      TUXBOX_XSHADER=str(repo / "build/pipeline-host/x86_64-unknown-linux-gnu/release/xshader"))
    for key in ("TUXBOX_LARGE_COMPILES", "TUXBOX_PIPELINE_DEADLINE"):
        os.environ.pop(key, None)
    provider = repo / "build/d3d12-smoke/d3d12_xs.dll"
    proton = Path.home() / "snap/steam/common/.local/share/Steam/steamapps/common/Proton - Experimental"
    with TemporaryDirectory(dir=out) as tmp:
        trial = Path(tmp)
        artifacts = [generate(trial, dxc, i) for i in range(args.count)]
        if len({row["sha256"] for row in artifacts}) != args.count:
            raise RuntimeError("Duplicate DXIL")
        (trial / "adapter.txt").write_text("10de:2702")
        (trial / "count.txt").write_text(str(args.count))
        cache = trial / "nvidia"
        cache.mkdir()
        os.environ["__GL_SHADER_DISK_CACHE_PATH"] = str(cache)
        shutil.copyfile(here / "guest.cpp", trial / "guest.cpp")
        settings = {"TUXBOX_NULL_PIPELINES":"0", "TUXBOX_LOG":"stderr"}
        exe, status, fields = run_gpu_guest(trial / "guest.cpp", "large.exe", trial, out, proton,
            build / "lanes-prefix", provider, tools / "dxc-windows",
            link_libraries=(provider.with_suffix(".lib"),), fresh_shader_cache=True,
            extra_env=settings)
        if status != 0 or fields != {"adapter":"10de:2702", "created":str(args.count)}:
            raise RuntimeError(f"guest returned {status}, {fields}; see {out / 'gpu.log'}")
        for row in artifacts:
            i = row["variant"]
            actual = (trial / f"output{i}.bin").read_bytes()
            if actual != expected(i):
                raise ValueError(f"GPU output mismatch for variant {i}")
            (out / f"output{i}.bin").write_bytes(actual)
            row["output_sha256"] = hashlib.sha256(actual).hexdigest()
            row["matched_uint32"] = len(actual) // 4
        wait = [line for line in (out / "gpu.log").read_text().splitlines()
                if "waits for one of 4 large compile slots" in line]
        receipt = dict(commit=subprocess.check_output(["git","-C",repo,"rev-parse","HEAD"],text=True).strip(),
            provider_sha256=hashlib.sha256(provider.read_bytes()).hexdigest(),
            guest_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
            gpu=subprocess.check_output(["nvidia-smi","--query-gpu=name,driver_version","--format=csv,noheader"],text=True).strip(),
            dxc=subprocess.check_output([dxc,"--version"],text=True).strip(),
            proton=(proton/"version").read_text().strip(), deadline_seconds=20,
            adapter=fields["adapter"], variants=artifacts, waits=wait)
        (out / "receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
        if len(wait) != (1 if args.count == 5 else 0):
            raise RuntimeError(f"Observed {len(wait)} waits; see receipt")
        if wait and not any("CS " + row["sha256"][:8] + " waits" in wait[0] for row in artifacts):
            raise RuntimeError("Wait message did not identify a submitted shader")
        print(f"PASS {args.count} pipelines, {64*args.count} matching outputs, {len(wait)} wait(s)")


if __name__ == "__main__":
    main()
