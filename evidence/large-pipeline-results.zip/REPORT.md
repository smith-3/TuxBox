# Five simultaneous large compute pipelines on an RTX 4080 SUPER

Tested TuxBox at `3f2a7177e4666658418dda89db9549a5d50f217b` on Ubuntu 24.04.5 with NVIDIA driver 570.211.01, Proton Experimental 11.0 (20261014) and Microsoft DXC 1.9.2609.5.

The single-shader pilot created a pipeline and returned all 64 expected integers. In the five-way test, one guest process released five threads together against the same device. Each thread submitted a distinct, DXV-validated DXIL through Xbox device slot 62. The executable DXIL chunks ranged from 604,772 to 604,784 bytes, above the 524,288-byte threshold. Each run started with fresh TuxBox, vkd3d and NVIDIA cache paths. Both the four-slot limit and the 20-second deadline used their defaults. We disabled null pipelines.

The provider logged a wait for shader `c7236539` in the first five-way run. All five creation calls succeeded. The guest then dispatched each pipeline, waited for its fence, and read back 64 integers per variant. All 320 matched the CPU reference byte for byte.

```text
TuxBox d3d12_xs: CS c7236539 waits for one of 4 large compile slots
```

A second cold run of the identical five binaries also recorded exactly one wait, this time for `ffdbf63e`. All 320 words matched again. Both batches finished within the default deadline.

This exercises the provider's admission of large, precompiled compute shaders. HLSL compilation took place before the guest started. Timing improvements and native Xbox shader translation require separate measurements. Earlier exploratory shaders using large lookup tables or a single long arithmetic chain exceeded the default deadline on this machine. The successful fixture splits the arithmetic into 64 branches and dispatches all 64.

## Reproduce locally

The package contains the generator, C++ guest, Python runner and JSON receipts. Each HLSL branch computes 540 dependent integer mixing rounds with variant-specific constants and writes one word to a UAV. The Python reference computes those words independently of the GPU. The guest initializes its buffer with a sentinel before dispatch.

The runner uses the TuxBox test helper `tools/frosty_gpu_guest.py` and the stock Proton Experimental files. On this workstation the TuxBox build directory contains `pipeline-candidate` (the tested checkout with release provider and xshader), `validation-tools` (DXC, DXV, Windows DXC DLLs, LLVM 19 and xwin SDK), and `lanes-prefix` (a test-only Wine prefix). For a different workstation, adapt those tool and Proton paths in `run.py`. Use a fresh output directory for every run.

```bash
rtk proxy python3 run.py pilot-new 1 --build-dir /home/smith/Documents/TuxBox/build
rtk proxy python3 run.py five-new 5 --build-dir /home/smith/Documents/TuxBox/build
```

Each successful run records the provider and guest hashes, the submitted shader hashes, their sizes, the GPU output hashes and the matching wait messages in `receipt.json`. The local run directory also retains the individual GPU readbacks and the full log.
