#include "compute_fixture.h"
#include <atomic>
#include <thread>
#include <fstream>
#include <iterator>
#include <vector>

using namespace compute_fixture;
using XboxPipeline = HRESULT (WINAPI*)(ID3D12Device*, const D3D12_COMPUTE_PIPELINE_STATE_DESC*,
                                       UINT, const void*, REFIID, void**);
using BindHeaps = void (WINAPI*)(ID3D12GraphicsCommandList*, UINT, ID3D12DescriptorHeap* const*);
using BindRoot = void (WINAPI*)(ID3D12GraphicsCommandList*, ID3D12RootSignature*);
using BindTable = void (WINAPI*)(ID3D12GraphicsCommandList*, UINT, D3D12_GPU_DESCRIPTOR_HANDLE);
using GpuHandle = UINT64 (WINAPI*)(ID3D12DescriptorHeap*);

static void dispatch(const ComPtr<ID3D12Device>& dev, const ComPtr<ID3D12RootSignature>& root,
                     const ComPtr<ID3D12PipelineState>& pipeline, unsigned index) {
    constexpr UINT lanes = 64, size = lanes * sizeof(UINT);
    auto output = buffer(dev.Get(), D3D12_HEAP_TYPE_DEFAULT, size, D3D12_RESOURCE_STATE_COPY_DEST,
                         D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
    auto readback = buffer(dev.Get(), D3D12_HEAP_TYPE_READBACK, size, D3D12_RESOURCE_STATE_COPY_DEST);
    auto initial = buffer(dev.Get(), D3D12_HEAP_TYPE_UPLOAD, size, D3D12_RESOURCE_STATE_GENERIC_READ);
    std::array<UINT, lanes> sentinel;
    sentinel.fill(~0u);
    upload(initial.Get(), sentinel.data(), size);
    ComPtr<ID3D12DescriptorHeap> descriptors;
    const D3D12_DESCRIPTOR_HEAP_DESC heap{
        D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV, 1, D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE, 1};
    check(dev->CreateDescriptorHeap(&heap, IID_PPV_ARGS(&descriptors)), "create descriptor heap");
    D3D12_UNORDERED_ACCESS_VIEW_DESC view{};
    view.Format = DXGI_FORMAT_R32_TYPELESS;
    view.ViewDimension = D3D12_UAV_DIMENSION_BUFFER;
    view.Buffer.NumElements = lanes;
    view.Buffer.Flags = D3D12_BUFFER_UAV_FLAG_RAW;
    const D3D12_CPU_DESCRIPTOR_HANDLE cpu{frame_abi::method<frame_abi::CpuHandle>(
        descriptors.Get(), 9)(descriptors.Get())};
    const D3D12_GPU_DESCRIPTOR_HANDLE gpu{frame_abi::method<GpuHandle>(
        descriptors.Get(), 10)(descriptors.Get())};
    dev->CreateUnorderedAccessView(output.Get(), nullptr, &view, cpu);

    ComPtr<ID3D12CommandQueue> queue;
    ComPtr<ID3D12CommandAllocator> allocator;
    ComPtr<ID3D12GraphicsCommandList> list;
    const D3D12_COMMAND_QUEUE_DESC queue_desc{D3D12_COMMAND_LIST_TYPE_COMPUTE, 0,
                                               D3D12_COMMAND_QUEUE_FLAG_NONE, 0};
    check(dev->CreateCommandQueue(&queue_desc, IID_PPV_ARGS(&queue)), "create queue");
    check(dev->CreateCommandAllocator(queue_desc.Type, IID_PPV_ARGS(&allocator)), "create allocator");
    const UINT list_desc[]{D3D12_COMMAND_LIST_TYPE_COMPUTE, 0, 1, 0};
    check(frame_abi::method<frame_abi::CreateList>(dev.Get(), 73)(
        dev.Get(), list_desc, allocator.Get(), nullptr, IID_PPV_ARGS(&list)), "create command list");
    check(list->Reset(allocator.Get(), pipeline.Get()), "start recording");
    list->CopyBufferRegion(output.Get(), 0, initial.Get(), 0, size);
    transition(list.Get(), output.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
               D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    ID3D12DescriptorHeap* heaps[]{descriptors.Get()};
    frame_abi::method<BindHeaps>(list.Get(), 32)(list.Get(), 1, heaps);
    frame_abi::method<BindRoot>(list.Get(), 33)(list.Get(), root.Get());
    frame_abi::method<BindTable>(list.Get(), 35)(list.Get(), 0, gpu);
    list->Dispatch(1, 1, 1);
    transition(list.Get(), output.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    list->CopyBufferRegion(readback.Get(), 0, output.Get(), 0, size);
    check(list->Close(), "close dispatch");
    ID3D12CommandList* batch[]{list.Get()};
    ComPtr<ID3D12Fence> fence;
    check(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence)), "create fence");
    queue->ExecuteCommandLists(1, batch);
    check(queue->Signal(fence.Get(), 1), "signal dispatch");
    wait_for_fence(fence.Get(), 1);
    void* mapped = nullptr;
    const D3D12_RANGE readable{0, size}, empty{};
    check(readback->Map(0, &readable, &mapped), "map output");
    std::ofstream bytes("output" + std::to_string(index) + ".bin", std::ios::binary);
    bytes.write(static_cast<const char*>(mapped), size);
    readback->Unmap(0, &empty);
    bytes.close();
    if (!bytes) throw std::runtime_error("write readback");
}

int main() {
    try {
        std::wstring adapter;
        std::wifstream adapter_file("adapter.txt");
        adapter_file >> adapter;
        if (adapter.empty()) throw std::runtime_error("missing adapter");
        DXGI_ADAPTER_DESC1 selected{};
        constexpr std::array<UINT, 18> creation{0x20004, 0, ~0u, 0, 0, 0, ~0u, ~0u, 0, 1};
        auto dev = frame_abi::create_device(adapter.c_str(), selected, creation.data());
        D3D12_DESCRIPTOR_RANGE uav{D3D12_DESCRIPTOR_RANGE_TYPE_UAV, 1, 0, 0, 0};
        D3D12_ROOT_PARAMETER table{};
        table.ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
        table.DescriptorTable = {1, &uav};
        const D3D12_ROOT_SIGNATURE_DESC signature{1, &table, 0, nullptr, D3D12_ROOT_SIGNATURE_FLAG_NONE};
        ComPtr<ID3DBlob> serialized;
        check(D3D12SerializeRootSignature(&signature, D3D_ROOT_SIGNATURE_VERSION_1, &serialized, nullptr),
              "serialize root signature");
        ComPtr<ID3D12RootSignature> root;
        check(dev->CreateRootSignature(0, serialized->GetBufferPointer(), serialized->GetBufferSize(),
                                        IID_PPV_ARGS(&root)), "create root signature");

        unsigned count = 0;
        std::ifstream("count.txt") >> count;
        if (count != 1 && count != 5) throw std::runtime_error("expected one or five shaders");
        std::vector<std::vector<char>> shaders(count);
        std::vector<ComPtr<ID3D12PipelineState>> pipelines(count);
        std::vector<HRESULT> results(count, E_FAIL);
        for (unsigned i = 0; i < count; ++i) {
            std::ifstream input("shader" + std::to_string(i) + ".cso", std::ios::binary);
            shaders[i].assign(std::istreambuf_iterator<char>(input), {});
            if (shaders[i].size() < 512 * 1024) throw std::runtime_error("shader below threshold");
        }
        std::atomic<unsigned> ready{0};
        std::atomic<bool> start{false};
        std::vector<std::thread> threads;
        for (unsigned i = 0; i < count; ++i) {
            threads.emplace_back([&, i] {
                D3D12_COMPUTE_PIPELINE_STATE_DESC desc{};
                desc.pRootSignature = root.Get();
                desc.CS = {shaders[i].data(), shaders[i].size()};
                ++ready;
                while (!start.load()) std::this_thread::yield();
                results[i] = frame_abi::method<XboxPipeline>(dev.Get(), 62)(
                    dev.Get(), &desc, 0, nullptr, IID_PPV_ARGS(&pipelines[i]));
            });
        }
        while (ready.load() != count) std::this_thread::yield();
        start.store(true);
        for (auto& thread : threads) thread.join();
        for (unsigned i = 0; i < count; ++i) {
            check(results[i], "create compute pipeline");
            if (!pipelines[i]) throw std::runtime_error("missing pipeline");
            dispatch(dev, root, pipelines[i], i);
        }
        std::ofstream report("result.txt");
        report << "adapter=" << std::hex << selected.VendorId << ':' << selected.DeviceId
               << std::dec << "\ncreated=" << count << "\n";
        report.close();
        return report ? 0 : 1;
    } catch (const std::exception& error) {
        std::ofstream report("result.txt");
        report << "error=" << error.what() << '\n';
        return 2;
    }
}
