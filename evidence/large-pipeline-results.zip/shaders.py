"""Generate independent integer compute shaders and verify their compiled size."""
import hashlib
import struct
import subprocess

ROUNDS = 540
MASK = 0xffffffff


def salts(variant, lane):
    return [((i+1)*0x9e3779b9 + variant*0x85ebca6b + lane*0x7f4a7c15) & MASK for i in range(ROUNDS)]


def expected(variant):
    lanes = list(range(64))
    for i, x in enumerate(lanes):
        for salt in salts(variant, i):
            x = (x + salt) & MASK
            x ^= x >> 9
        lanes[i] = x
    assert len(set(lanes)) == 64 and MASK not in lanes
    return struct.pack("<64I", *lanes)


def generate(directory, dxc, variant):
    source = directory / f"shader{variant}.hlsl"
    binary = source.with_suffix(".cso")
    with source.open("w") as f:
        f.write("RWByteAddressBuffer dst : register(u0);\n"
                "[numthreads(64,1,1)] void main(uint3 id : SV_DispatchThreadID) {\n"
                "uint x = id.x;\n")
        f.write("switch (id.x & 63u) {\n")
        for lane in range(64):
            f.write(f"case {lane}u:\n")
            for salt in salts(variant, lane):
                f.write(f"x += 0x{salt:08x}u; x ^= x >> 9;\n")
            f.write("break;\n")
        f.write("}\ndst.Store(id.x * 4u, x);\n}\n")
    subprocess.run([dxc, "-T", "cs_6_0", "-E", "main", "-O3", "-Fo", binary, source], check=True)
    subprocess.run([dxc.with_name("dxv"), binary], check=True)
    data = binary.read_bytes()
    count, = struct.unpack_from("<I", data, 28)
    offsets = struct.unpack_from(f"<{count}I", data, 32)
    dxil, = [offset for offset in offsets if data[offset:offset+4] == b"DXIL"]
    size, = struct.unpack_from("<I", data, dxil+4)
    if size < 512 * 1024:
        raise ValueError(f"DXIL chunk only {size} bytes")
    source.with_suffix(".expected").write_bytes(expected(variant))
    return dict(variant=variant, bytes=len(data), dxil_chunk_bytes=size,
                sha256=hashlib.sha256(data).hexdigest())
